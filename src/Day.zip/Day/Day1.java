package Day;

public class Day1 {
	// instance variables
	int test = 10;

	// instance method
	public void test() {
		// local variable
		int test = 10;
		System.out.println(test);
		date();
	}

	// Static method
	public static void date() {
		System.out.println("Hello");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Day1 d = new Day1();//
		d.test();//instance method calling
		
		Day1.date();
		

	}

}
