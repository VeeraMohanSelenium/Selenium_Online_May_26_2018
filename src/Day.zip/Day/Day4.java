package Day;

public class Day4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//conditional statements
		
		//if
		//ifelse
		//switch
		//ifelseif
		
		
		//if conditon
		
		int a=10;
		int b=20;
		if(a<=b)
		{
			System.out.println("a is greaterthen b");
		}
		else
		{
			System.out.println("a is lessthan b");
			
		}
		
		//switch condition
		int y=40;
		String browser="Firefo5x";
		
		switch (browser) {
		case "ie":
			
			System.out.println("Hello");
			break;
		case "Firefox":
			System.out.println("World");
			break;
			

		default:
			System.out.println("Hello World");
			break;
		}
		
		//ifelseif
		int f=20;
		int g=10;
		if(f>g)
		{
			System.out.println("f greater than g");
		}
		else if (f==g) {
			System.out.println("f equal g");
			
		}
		else if (f!=g) {
			System.out.println("f notequal g");
			
		}
		else
		{
			System.out.println("Default");
		}

	}

	

}
