package Day;

public class Day2 {
	
	
	

	public static void main(String[] args) {
		
		//operators
		//+,-,*,/,%,<,>,<=,>=
		
		int a=30;
		int b=40;
		int c=a+b;
		System.out.println(c);
		System.out.println(a-b);
		System.out.println(a*b);
		System.out.println(a/b);
		System.out.println(a%b);
		System.out.println();
		

	}
	
	public void test()
	{
		
	}
	
	
	

}
