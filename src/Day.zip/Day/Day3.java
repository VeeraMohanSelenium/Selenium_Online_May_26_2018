package Day;

public class Day3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Looping conditions

		// for-- Size
		// foreach
		// while
		// do-while

		// Syntax for loop

		// for (intialvalue;Condition;increment)
		// {
		//
		// }
		// for (int i = 0; i <= 10; i++) {
		//
		// int a = 2;
		// System.out.println(a + "*" + i + "=" + a * i);
		//
		//
		// }
		//
		for (int i = 0; i <= 10;i++) {

			int a = 2;
			System.out.println(a + "*" + i + "=" + a * i);
			

			
		}

		// while sysntax
		// while (condition) {
		//
		// increment;
		//
		// }

		int c = 3;
		int s = 0;
		int d = 10;
		while (s <= d) {

			System.out.println(c + "X" + s + "=" + c * s);

			s++;

		}
		
		//do-while
		
//		do {
//			
//		} while (condition);

	}

}
